package com.scheduler.app.scheduler;

import com.scheduler.app.exception.SchedulerExecutionException;
import com.scheduler.app.model.SchedulerResult;
import com.scheduler.app.properties.SchedulerProperties;
import com.scheduler.app.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

/**
 * Master Scheduler Component.
 *
 * Hosts all @Scheduled methods. Each method runs on a separate thread
 * from the ThreadPoolTaskScheduler configured in ThreadPoolConfig.
 *
 * Cron expressions are defined in application.properties and loaded
 * via InputStream by SchedulerProperties.
 *
 * Exception handling:
 *  - SchedulerExecutionException is caught, recorded, and logged
 *  - The scheduler continues running even after failures
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MasterScheduler {

    private final EmailService            emailService;
    private final ReportService           reportService;
    private final CleanupService          cleanupService;
    private final NotificationService     notificationService;
    private final DataSyncService         dataSyncService;
    private final SchedulerProperties     schedulerProperties;
    private final SchedulerExecutionTracker tracker;

    // ─── Email Scheduler ──────────────────────────────────
    // Cron loaded from application.properties: scheduler.email.cron

    @Scheduled(cron = "${scheduler.email.cron}")
    public void runEmailScheduler() {
        if (!schedulerProperties.isEmailEnabled()) {
            log.info("📧 EmailScheduler is disabled. Skipping.");
            return;
        }
        executeWithTracking("EmailScheduler", () -> emailService.processPendingEmails());
    }

    // ─── Report Scheduler ─────────────────────────────────
    // Cron loaded from application.properties: scheduler.report.cron

    @Scheduled(cron = "${scheduler.report.cron}")
    public void runReportScheduler() {
        if (!schedulerProperties.isReportEnabled()) {
            log.info("📊 ReportScheduler is disabled. Skipping.");
            return;
        }
        executeWithTracking("ReportScheduler", () -> reportService.generateDailyReport());
    }

    // ─── Cleanup Scheduler ────────────────────────────────
    // Cron loaded from application.properties: scheduler.cleanup.cron

    @Scheduled(cron = "${scheduler.cleanup.cron}")
    public void runCleanupScheduler() {
        if (!schedulerProperties.isCleanupEnabled()) {
            log.info("🧹 CleanupScheduler is disabled. Skipping.");
            return;
        }
        executeWithTracking("CleanupScheduler", () -> cleanupService.runNightlyCleanup());
    }

    // ─── Notification Scheduler ───────────────────────────
    // Cron loaded from application.properties: scheduler.notification.cron

    @Scheduled(cron = "${scheduler.notification.cron}")
    public void runNotificationScheduler() {
        if (!schedulerProperties.isNotificationEnabled()) {
            log.info("🔔 NotificationScheduler is disabled. Skipping.");
            return;
        }
        executeWithTracking("NotificationScheduler",
                () -> notificationService.dispatchNotifications());
    }

    // ─── Data Sync Scheduler ──────────────────────────────
    // Cron loaded from application.properties: scheduler.data-sync.cron

    @Scheduled(cron = "${scheduler.data-sync.cron}")
    public void runDataSyncScheduler() {
        if (!schedulerProperties.isDataSyncEnabled()) {
            log.info("🔄 DataSyncScheduler is disabled. Skipping.");
            return;
        }
        executeWithTracking("DataSyncScheduler", () -> dataSyncService.syncData());
    }

    // ─── Execution Wrapper ────────────────────────────────

    /**
     * Executes a scheduled task with:
     *  - Thread name logging
     *  - Exception catching and recording
     *  - Execution tracking via SchedulerExecutionTracker
     *  - Retry logic (configurable via properties)
     */
    private void executeWithTracking(String schedulerName, SchedulerTask task) {
        int maxAttempts = schedulerProperties.getRetryMaxAttempts();
        long retryDelay = schedulerProperties.getRetryDelayMs();

        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                log.info("▶️  [{}] Executing on thread: {}",
                        schedulerName, Thread.currentThread().getName());

                SchedulerResult result = task.execute();
                tracker.record(result);
                return; // Success — exit retry loop

            } catch (SchedulerExecutionException e) {
                log.error("❌ [{}] Attempt {}/{} failed: {}",
                        schedulerName, attempt, maxAttempts, e.getMessage());

                if (schedulerProperties.isLogStackTrace()) {
                    log.error("Stack trace:", e);
                }

                SchedulerResult failedResult = SchedulerResult.builder()
                        .schedulerName(schedulerName)
                        .status("FAILED")
                        .threadName(Thread.currentThread().getName())
                        .message("Attempt " + attempt + " failed: " + e.getMessage())
                        .errorDetail(e.getErrorCode())
                        .build();
                tracker.record(failedResult);

                if (attempt < maxAttempts) {
                    log.info("⏳ [{}] Retrying in {}ms (attempt {}/{})",
                            schedulerName, retryDelay, attempt + 1, maxAttempts);
                    try {
                        Thread.sleep(retryDelay);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                } else {
                    log.error("🔴 [{}] All {} attempts failed. Giving up until next scheduled run.",
                            schedulerName, maxAttempts);
                }

            } catch (Exception e) {
                // Unexpected exception — don't retry
                log.error("🔴 [{}] Unexpected exception (no retry): {}", schedulerName, e.getMessage(), e);

                SchedulerResult failedResult = SchedulerResult.builder()
                        .schedulerName(schedulerName)
                        .status("FAILED")
                        .threadName(Thread.currentThread().getName())
                        .message("Unexpected error: " + e.getMessage())
                        .errorDetail(e.getClass().getSimpleName())
                        .executedAt(LocalDateTime.now())
                        .build();
                tracker.record(failedResult);
                return;
            }
        }
    }

    /**
     * Functional interface for scheduler task execution.
     */
    @FunctionalInterface
    interface SchedulerTask {
        SchedulerResult execute() throws SchedulerExecutionException;
    }
}
